#ifndef __PROCEDURE_H
#define __PROCEDURE_H
#include "main.h"
#include "tim.h"
float update_infinite_angle(float raw_angle);
void delay_1us(uint32_t xus);
void Hcsr04GetLength(void);
#endif

