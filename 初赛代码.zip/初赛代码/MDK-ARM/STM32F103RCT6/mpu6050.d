stm32f103rct6/mpu6050.o: ..\BSP\MPU6050.c
