from maix import camera, display, image, nn, app, uart, time

# 硬件初始化
device = "/dev/ttyS0"
serial0 = uart.UART(device, 115200)
detector = nn.YOLOv5(model="/root/models/maixhub/gc/8_4.mud")
cam = camera.Camera(320, 240, detector.input_format())
dis = display.Display()

# 预定义常量
LABEL_LIST = ["red", "blue", "black", "yellow", "red_zone", "blue_zone","red_go", "blue_go","cross", "green"]  # 调整标签名称确保匹配
# 0红球 1蓝球 2黑球 3黄球 4红安全区 5蓝安全区 6红出发区 7蓝出发区 8中心十字架 9绿色障碍物

# 动态生成映射关系（模型标签名到用户标签索引）
mapping_list = []
for model_label in detector.labels:
    model_label_clean = model_label.strip().lower()  # 清理模型标签名称
    found_index = -1
    for idx, user_label in enumerate(LABEL_LIST):
        if model_label_clean == user_label.strip().lower():
            found_index = idx
            break
    mapping_list.append(found_index)

color = [9] * 10  # 10种颜色状态
c_x = [0] * 11   
c_y = [0] * 11   # 索引11专门用于find=10的坐标
num = [0]*9      #记录所有目标的个数
ball= 0          #记录视野中球的个数
find = 10         # 10默认无目标
fps_counter = 0
last_fps_time = time.ticks_ms()

while not app.need_exit():
    # 非阻塞FPS计算（每30帧输出一次）
    fps_counter += 1
    if fps_counter >= 3:
        interval = time.ticks_diff(time.ticks_ms(), last_fps_time)
        print(f"FPS: {1000/(interval/fps_counter):.1f}")
        fps_counter = 0
        last_fps_time = time.ticks_ms()
    # 非阻塞读取串口
    if receive := serial0.read(1):
        if 0<=(new_find := int.from_bytes(receive, 'little') - 48) <=8:
            find = new_find
    
    # 重置数据
    color = [9]*10
    c_x = [0]*11 # 比循环清零更快
    c_y = [0]*11
    num = [0]*10
    ball= 0 
    zone_x=0
    zone_y=0
    green_x=0
    green_y=0
    # 图像处理流水线
    img = cam.read()
    # img = img.gamma_corr(gamma=1.05, contrast=1.05, brightness=0.01)  
    for obj in detector.detect(img, conf_th = 0.7, iou_th = 0.25):
        
        # 缓存对象属性
        x, y, w, h = obj.x, obj.y, obj.w, obj.h
        Rx = x + w//2
        Ry = y + h//2
        # 绘制操作保持不变
        img.draw_rect(x, y, w, h, image.COLOR_RED)
        img.draw_string(x, y, f"{detector.labels[obj.class_id]}:{obj.score:.2f}", image.COLOR_RED)
        img.draw_string(x, Ry, f"({Rx},{240-Ry})", image.COLOR_RED)

        cls_id = mapping_list[obj.class_id] if obj.class_id < len(mapping_list) else -1
        if cls_id in (4,5):
            zone_x=Rx
            zone_y=240-y-h
            c_x[cls_id] = Rx
            c_y[cls_id] = Ry
            color[cls_id]=cls_id
        elif cls_id in (0,1,2,3,6,7,8,9) :
            color[cls_id]=cls_id 
            num[cls_id]=num[cls_id]+1
            if find == cls_id  and Ry > c_y[cls_id] :
                c_x[cls_id] = Rx
                c_y[cls_id] = Ry    # 坐标
            elif  cls_id==9 and Ry > c_y[9]:
                green_x=Rx
                green_y=240-y-h

    # 统一数据发送（无论是否检测到目标）
    ball=num[0]+num[1]+num[2]+num[3]
    target_x = c_x[find] if find <9 else c_x[9]
    target_y = 240 - (c_y[find] if find <9 else c_y[9])   

    print(f"红:{color[0]} 蓝:{color[1]} 黑:{color[2]}黄：{color[3]} 红安:{color[4]} 蓝安:{color[5]} "
            f"目标:{target_x:03d} {target_y:03d} 红出:{color[6]} 蓝出:{color[7]} 十字架:{color[8]} "
            f"ball:{ball} find:{find} 安全区:{zone_x:03d} {zone_y:03d} 绿:{green_x:03d} {green_y:03d}\r\n")
            # 打印生成的字符串
    serial0.write_str(
        f"@{color[0]}{color[1]}{color[2]}{color[3]}{color[4]}{color[5]}{target_x:03d}{target_y:03d}{color[6]}{color[7]}{color[8]}{ball}{zone_x:03d}{zone_y:03d}{green_x:03d}{green_y:03d}\r\n"
    )  

    dis.show(img)

# 资源释放
cam.close()
