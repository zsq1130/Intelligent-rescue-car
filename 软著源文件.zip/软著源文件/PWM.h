#ifndef __PWM_H
#define __PWM_H
#include "main.h"
#include "tim.h"
//void PWM1_Init(void);
////void PWM2_Init(void);
////void PWM3_Init(void);
////void PWM4_Init(void);
//void PWM5_Init(void);


void PWM_SetCompare1(uint16_t Compare);
void PWM_SetCompare2(uint16_t Compare);
void PWM_SetCompare3(uint16_t Compare);
void PWM_SetCompare4(uint16_t Compare);

void PWM_DSetC1(uint16_t Compare);
void PWM_DSetC2(uint16_t Compare);
void PWM_DSetC3(uint16_t Compare);
void PWM_DSetC4(uint16_t Compare);
void angle_tuiqiu(void);
void quekou_close(void);
void chuizhi_open(void);
void bihe(void);
void quan_kai(void);
#endif
