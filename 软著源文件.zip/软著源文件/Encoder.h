#ifndef __ENCODER_H
#define __ENCODER_H
#include "main.h"
#include "tim.h"
//void Encoder1_Init(void);
////int16_t Encoder1_GetCNT(void);
////int16_t Encoder1_GetSpeed(void);
//void Encoder2_Init(void);
////int16_t Encoder2_GetCNT(void);
////int16_t Encoder2_GetSpeed(void);
//void Encoder3_Init(void);
int16_t Encoder3_GetCNT(void);
int16_t Encoder3_GetSpeed(void);
//void Encoder4_Init(void);
int16_t Encoder4_GetCNT(void);
int16_t Encoder4_GetSpeed(void);
#endif
