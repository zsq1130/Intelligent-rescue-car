#ifndef __TIMER_H
#define __TIMER_H
#include "main.h"  
#include "adc.h"
#include "PID_define.h"
extern pid_type_def X_pid;
extern pid_type_def Y_pid;
extern pid_type_def Left_speed_pid;
extern pid_type_def Right_speed_pid;
extern pid_type_def Left_speed__dalt_pid;
extern pid_type_def Right_speed_dalt_pid;
extern pid_type_def angle_pid;
extern int what_ball;
extern char temp[20];	
extern UART_HandleTypeDef huart5;
extern int Speed_Left;
extern int Speed_Right;
extern int red_,yellow_,black_,blue_,safe_blue,safe_red,go_red,go_blue,cross,number,x_safe,y_safe;
extern int count_;
extern int flag;
extern int time_begin,stop_flag;
extern float a_x,a_y,a_z;
extern int get_ball;
extern int red_or_blue;  //1blue 2red
extern int lose_time,losef;
extern int lose__flag;
extern int time_task1;
extern int time_task1_flag;
extern fp32 k_X_pid[3];
extern fp32 k_Y_pid[3];//0.5
extern fp32 k_X_safe_pid[3];
extern fp32 k_Y_safe_pid[3];
extern int  aa,possess,num_flag,flag_1,zizhuan_dir_red,zizhuan_dir_blue,go_go_flag,re_houtui_time,jiaoluo_addres_time;
extern float yaw;
extern uint16_t count_a;
extern float Yaw_speed ;
extern  int place,situation,jiancha,zhuaqiu_back_time;
extern double adc1,adc2;
double get_adc_val( ADC_HandleTypeDef *hadc);
void Delay_us(uint32_t xus);
uint16_t Echo_Measure(void);
#endif
