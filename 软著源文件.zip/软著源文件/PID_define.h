#ifndef __PID_DEFINE_H
#define __PID_DEFINE_H
#include "MY_pid.h"
#include "main.h"
#include "IMU.h"
#include "math.h"
#include "usart.h"
#define LimitMax(input, max)   \
    {                          \
        if (input > max)       \
        {                      \
            input = max;       \
        }                      \
        else if (input < -max) \
        {                      \
            input = -max;      \
        }                      \
    }
void MY_pid_Init(void);		
void PID_action(fp32 x_set,fp32 y_set);
void judge(void)	 ;
void find_ball(void);
void PID_action_Safe(fp32 x_set,fp32 y_set);
void go_go(void);
void zizhuan_pid(void);
void Get_close_to_the_target_ball(void); //flag=0
void Grab_the_target_ball(void);//flag=1
void Go_to_the_safe_zone(void);//flag=2
void Towards_the_safety_zone(void);//flag=3
void Exit_the_safe_zone(void);//flag=4
void Find_the_lost_ball(void); //flag=5
void check(void);//flag=6
void Spot_the_ball_halfway_through(void);
void Look_for_the_cross(void);
void go_ahead(void);
void re_Exit_the_safe_zone(void);
void re_go_to_the_safe_zone(void);
void get_three_balls(void);
void PID_action_ANGLE(fp32 SET);
void after_kasi_jiaoluo(void);
void go_to_go_zone(void);
void after_kazhu_situation1(void);
void situation_address1(void);
void go_ahead_situation1(void);
void after_kazhu(void);
void re_zizhuan_pid(void);
void  grab_the_ball_safe(void);
void  to_center_than_to_red_go(void);void to_red_go(void);void  to_center_than_to_blue_go(void);void to_blue_go(void);void go_ahead_red(void);void go_ahead_blue(void);
void spot_the_ball(void);
void go_zone_find_ball(void);
void zhangzhua_back(void);
void go_blue_go(void);void go_red_go(void);
void re_houtui(void);void qianjin_jiaoluo(void);void jiaoluo_addres(void);void qianjin_little(void);void stop(void);
void zhuaqiu_back(void);
void go_ahead_red_(void);void go_ahead_blue_(void);
void after_one_min(void);void f40_back(void);
void one_min(void);void f50_zhuan(void);
extern int houtui_time,HOUTUI_TIME,stop_time;
extern int lose;
extern int red_,yellow_,black_,blue_,safe_blue,safe_red,go_red,go_blue,cross,x_safe;
extern int what_ball;
extern int team;
extern int flag2;
extern int time2;
extern int flag3;
extern int time3;
extern int round_;
extern int32_t sum_encode_left;
extern int32_t sum_encode_right;
extern int red_or_blue;  
extern int check_time,check_flag;
extern int back_time,back_flag;
extern int Speed_Left;
extern int Speed_Right;
extern int cross_flag,find_cross_time;
extern int find_go_blue_time,go_blue_flag;
extern int find_go_red_time,go_red_flag;
extern float Roll_last,Pitch_last,Yaw_last;
extern  float Yaw_speed ;
extern  int cross_flag,find_cross_time;
extern  int number,lenque_time,hou_time;
extern int get_ball_time,get_ball_flag;
extern int kasi_flag,dis;
extern int jiaoluo_flag,jiaoluo_time,zhangzhua_back_time,go_ahead_red_time,go_ahead_blue_time;
extern int get_time,get_ball_flag;
extern int zizhuan_flag,y_safe,x_safe,f50_time;

#endif		
//void close_boll(void);
//void goto_safe(void);		
	
		
		
