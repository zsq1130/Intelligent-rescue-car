#include "PID_define.h"
#include "Motor.h"
/*********************����ı���****************/
int aa;
int count_=1800;
int flag=10000;
int get_ball=0;
int m=0;
int Go_to_the_safe_zone_flag=0;
fp32 x_ref,y_ref;
fp32 x_ref_,y_ref_;
fp32 x_set,y_set;
pid_type_def X_pid;
pid_type_def Y_pid;
pid_type_def X_safe_pid;
pid_type_def Y_safe_pid;
pid_type_def leftmotor_speed;
pid_type_def rightmotor_speed;

pid_type_def angle_pid;
pid_type_def angle_speed_pid;

fp32 k_X_pid[3]={13,0.8,1.5};
fp32 k_Y_pid[3]={45,0,0};//0.5
fp32 k_X_safe_pid[3]={10,0.5,0.5};
fp32 k_Y_safe_pid[3]={40,3,4};
fp32 k_leftmotor_speed_pid[3]={50,20,0};
fp32 k_rightmotor_speed_pid[3]={50,20,0};

fp32 k_angle_pid[3]={20,1,50};
fp32 k_angle_speed_pid[3]={2,1,0};

int time_begin=0;
int lose__flag=0;
int lose_time=0,losef=0;
int time_task1;
int time_task1_flag;
int situation=0;
extern int last_flag,last_last_flag;
int possess=0;
int num_flag=0;
int situ_time1;
int flag_0=1,flag_1=1;
int exit_time;
int stop_flag=0;
int go_color=1;
int zizhuan_dir_red=1,zizhuan_dir_blue=1;
int aaaaaaa=0;
int place=0;
int jiancha;
int situation_;
int k_f=1,kf_f=0;
int zizhuandir_red=1,zizhuandir_blue=1,re_houtui_time,jiaoluo_addres_time,zhuaqiu_back_time;
uint16_t count_a;
//#define  X_BALL_SET     144
//#define  Y_BALL_SET     75 
//#define  OUT_X_FLAG_0         //��һ�ֳ���ֵ
//#define  OUT_Y_FLAG_0
//#define  OUT_X_FLAG_1              //�ڶ��ֳ���ֵ
//#define  OUT_Y_FLAG_1
/*********************EXTERN*******************/

void PID_action_ANGLE(fp32 SET)
{
	
	  PID_calc(&angle_speed_pid,Yaw_speed,40);
		Motor3_SetSpeed(-angle_speed_pid.out);//��
		Motor4_SetSpeed(+angle_speed_pid.out);//��
}
void Spot_the_ball_halfway_through(void)
{
	if(Go_to_the_safe_zone_flag==1&&flag==2&&round_==2)
	{
		if(red_or_blue==1)//����
		{
			if(safe_blue==9&&(blue_!=9||black_!=9||yellow_!=9))//û������ȫ�����ǿ�������
			{
				Go_to_the_safe_zone_flag = 0;flag=0;get_ball=0;count_=1740;
			}
		  else	if(safe_blue!=9&&blue_==9&&black_==9&&yellow_==9)//������ȫ����û������
			{
				Go_to_the_safe_zone_flag = 0;flag=7;get_ball=1;count_=1740;
			}
			else if(safe_blue!=9&&(blue_!=9||black_!=9||yellow_!=9))//���߶�����
			{
				Go_to_the_safe_zone_flag = 0;flag=0;get_ball=0;count_=1740;
			}
			else if(safe_blue==9&&(blue_==9&&black_==9&&yellow_==9))
      {flag=7;count_=1740;get_ball=1;}
		}
		if(red_or_blue==2)//���
		{
			if(safe_red==9&&(red_!=9||black_!=9||yellow_!=9))//û������ȫ�����ǿ�������
			{
				Go_to_the_safe_zone_flag = 0;flag=0;get_ball=0;count_=1740;
			}
			else if(safe_red!=9&&red_==9&&black_==9&&yellow_==9)//������ȫ����û������
			{
				Go_to_the_safe_zone_flag = 0;flag=7;get_ball=1;count_=1740;
			}
			else if(safe_red!=9&&(red_!=9||black_!=9||yellow_!=9))//���߶�����
			{
				Go_to_the_safe_zone_flag = 0;flag=0;get_ball=0;count_=1740;
			}
			else if(safe_red==9&&(red_==9&&black_==9&&yellow_==9))
      {flag=7;count_=1740;get_ball=1;}
		}
		if(flag==7){flag=2;}
	}
}








void after_kasi_jiaoluo(void)
{
	if(flag==13)
	{
			flag=1;get_ball=0;jiaoluo_time=0;flag_1+=10;
      lose=1;
	}
}


void MY_pid_Init(void)
{
	  PID_init(&X_pid,PID_POSITION,k_X_pid,5000,10);
		PID_init(&Y_pid,PID_POSITION,k_Y_pid,5000,1000);
	
	  PID_init(&X_safe_pid,PID_POSITION,k_X_safe_pid,5000,10);
		PID_init(&Y_safe_pid,PID_POSITION,k_Y_safe_pid,5000,2000);

	  PID_init(&leftmotor_speed,PID_POSITION,k_leftmotor_speed_pid,10000,10000);
	  PID_init(&rightmotor_speed,PID_POSITION,k_rightmotor_speed_pid,10000,10000);
	
	  PID_init(&angle_pid,PID_POSITION,k_angle_pid,10000,10000);
	  PID_init(&angle_speed_pid,PID_POSITION,k_angle_speed_pid,10000,10000);
}


void zizhuan_pid(void)
{
	 PID_calc(&leftmotor_speed,Speed_Left,-10);
	 PID_calc(&rightmotor_speed,Speed_Right,-10);
	 LimitMax(leftmotor_speed.out,10000);
	 LimitMax(rightmotor_speed.out,10000);
	
	Motor3_SetSpeed(leftmotor_speed.out);//��
	Motor4_SetSpeed(-rightmotor_speed.out);//��
}

void re_zizhuan_pid(void)
{
	 PID_calc(&leftmotor_speed,Speed_Left,+10);
	 PID_calc(&rightmotor_speed,Speed_Right,+10);
	 LimitMax(leftmotor_speed.out,10000);
	 LimitMax(rightmotor_speed.out,10000);
	
	Motor3_SetSpeed(leftmotor_speed.out);//��
	Motor4_SetSpeed(-rightmotor_speed.out);//��
}



void PID_action(fp32 x_set,fp32 y_set)
{

	 PID_calc(&X_pid,x_ref,x_set);
	 LimitMax(X_pid.out,10000);
//	
   PID_calc(&Y_pid,y_ref,y_set);
	 LimitMax(Y_pid.out,10000);
}


void PID_action_Safe(fp32 x_set,fp32 y_set)
{
	 PID_calc(&X_safe_pid,x_ref,x_set);
	 LimitMax(X_safe_pid.out,10000);

   PID_calc(&Y_safe_pid,y_ref,y_set);
	 LimitMax(Y_safe_pid.out,10000);
	
}
void Get_close_to_the_target_ball(void)
{
		if(flag==0)
	{
		
		if(flag_0==1){flag_0=0;}
//		quekou_close();
		bihe();
		if(round_==1)//��һ��
		{
			if(red_or_blue==1){what_ball=1;}//����//����
			if(red_or_blue==2){what_ball=0;}//���//����
		}
		if(round_==2)//�ڶ���
			
		{    
			if(red_or_blue==1){what_ball=1;}//����//����
			if(red_or_blue==2){what_ball=0;}//���//����
			judge();
		}

		if(round_==1)//��һ��
		{
			/**********************1*********************/
//			k_X_pid[0]=7;  k_X_pid[1]=1;  k_X_pid[2]=0.5;
//			k_Y_pid[0]=20; k_Y_pid[1]=0.5;  k_Y_pid[2]=4;
			/**********************2*********************/
//			 k_X_pid[0]=600;  k_X_pid[1]=20;  k_X_pid[2]=0.5;//6  0.8
//			 k_Y_pid[0]=20; k_Y_pid[1]=0.5;  k_Y_pid[2]=4;
			PID_action(144,75);
			Motor3_SetSpeed(+X_pid.out-Y_pid.out);//��
			Motor4_SetSpeed(-X_pid.out-Y_pid.out);//��
			
				 if(lose==1)//����ʧ
					{zizhuan_pid();lose__flag=1;
					 sum_encode_left=0;
					 sum_encode_right=0;
					 flag=5;
					}
					
			if(y_ref<=115)
			{  count_-=7;/*count_a+=7;*/if(count_<1550){count_=1550;}/*if(count_a>low){count_a=low;}*/}
			if(y_ref>=180)
			{  count_+=7;/*count_a-=7;*/if(count_>=1740){count_=1740;}/*if(count_a<high){count_a=high;}*/}
       count_a = 2398-count_;PWM_DSetC4(count_a);
			PWM_DSetC2(count_);
			/****/
			/*PWM_DSetC4(count_);	*/
			if((count_<1600)&&((x_ref<=164)&&(x_ref>=124))&&((y_ref<=110)&&(y_ref>=72)))//�Ѿ�����Ŀ����Ȼ���צ�ӣ�flag0��1
			{chuizhi_open();flag=1;}
		}
	 if(round_==2)//�ǵ�һ��
		{
			/**********************1*********************/
//			 k_X_pid[0]=7;  k_X_pid[1]=1;  k_X_pid[2]=0.5;//6  0.8
//			 k_Y_pid[0]=20; k_Y_pid[1]=0.5;  k_Y_pid[2]=4;
			/**********************2*********************/
//			 k_X_pid[0]=14;  k_X_pid[1]=1;  k_X_pid[2]=0.5;//6  0.8
//			 k_Y_pid[0]=20; k_Y_pid[1]=0.5;  k_Y_pid[2]=4;
			 PID_action(144,75);
			 Motor3_SetSpeed(+X_pid.out-Y_pid.out);//��
			 Motor4_SetSpeed(-X_pid.out-Y_pid.out);//��
				if(lose==1)//����ʧ
				{zizhuan_pid();lose__flag=1;
				 sum_encode_left=0;
				 sum_encode_right=0;
				 flag=5;
				}
			if(y_ref<=115)
			{  count_-=7;if(count_<1550){count_=1550;}}
			if(y_ref>=180)
			{	 count_+=7;if(count_>=1740){count_=1740;}}
			PWM_DSetC2(count_); count_a = 2398-count_;PWM_DSetC4(count_a);

			/*PWM_DSetC4(count_);	*/
			if((count_<1600)&&((x_ref<=152)&&(x_ref>=136))&&((y_ref<=110)&&(y_ref>=70)))//�Ѿ�����Ŀ����Ȼ���צ�ӣ�flag0��1
			{flag=1;		chuizhi_open();}

		}	
	}
}
void Grab_the_target_ball(void)
{
		if(flag==1)
	{
	  PID_action(144,37);
		Motor3_SetSpeed(+X_pid.out-Y_pid.out);//��
		Motor4_SetSpeed(-X_pid.out-Y_pid.out);//��
		if(lose==1)//����ʧ
			{zizhuan_pid();/**/lose__flag=1;//2
			 sum_encode_left=0;
			 sum_encode_right=0;
			 flag=5;
			}
		if(y_ref<=115)
	{  count_-=7;if(count_<=1400){count_=1400;}}
		if(y_ref>=180)
	{  count_+=7;if(count_>=1740){count_=1740;}}
		PWM_DSetC2(count_);	       count_a = 2398-count_;PWM_DSetC4(count_a);
	/*  PWM_DSetC4(count_);	*/
	
	if(((count_<1450)&&(y_ref<=60))||(jiaoluo_flag==1))
		{		
//		quekou_close();
			bihe();
			kasi_flag=0;
			Motor3_SetSpeed(0);//��
			Motor4_SetSpeed(0);//��
			count_=1740;PWM_DSetC2(count_);	count_a = 2398-count_;PWM_DSetC4(count_a);			/*PWM_DSetC4(count_);*/
			time2=0;
			time_begin=1;
			get_ball=1;
			place=0;
	 if(get_ball==1)
			{
				//PWM_DSetC4(1400);//����
	      place=0;
//			jiaoluo_flag=0;
				jiaoluo_time=0;
				count_=1050;
				//PWM_DSetC4(count_);//����
				PWM_DSetC2(count_);//����ͷ//1500 1225
				count_a = 2398-count_;PWM_DSetC4(count_a);
				flag=6;
				check_flag=0;
		    check_time=0;							
			}
		}
	}
}
void Go_to_the_safe_zone(void)
{
		if(flag==2)
	{
		  Go_to_the_safe_zone_flag=1;
			count_=1740;
      PWM_DSetC2(count_);//����ͷ//1500 1225
		count_a = 2398-count_;PWM_DSetC4(count_a);
				//	PWM_DSetC4(count_);	
		  if(red_or_blue==1){what_ball=5;}//����//����ȫ��
			if(red_or_blue==2){what_ball=4;}//���//�찲ȫ��
		  PID_action_Safe(160,70);
		  Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
		  Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
		
		  if(lose==1){zizhuan_pid();}//��ʧ��ȫ��Ŀ����ת
      if(y_ref<=80&&flag2==1)    //flag2��ʾʶ��ȫ������2��
		  {
//       Motor3_SetSpeed(2500);    //��
//		   Motor4_SetSpeed(2500);    //��
	     time3=0;                  //���ڼ����ӵִﰲȫ�����ٵ�ʱ��
			 Go_to_the_safe_zone_flag=0;
			 flag=3;
		  }
	}
}
void Towards_the_safety_zone(void)
{
		if(flag==3)
	{
//	  Motor3_SetSpeed(3500);//��//3500
//		Motor4_SetSpeed(3500);//��//3500
		/**************2***************/
		Motor3_SetSpeed(5000);//��//3500
		Motor4_SetSpeed(5000);//��//3500
		angle_tuiqiu();
		time_begin=0;
		flag2=0;  
		exit_time++;

	  if(flag3==1||exit_time==500){flag=4;exit_time=0;}				
	} 
}
void Exit_the_safe_zone(void)
{
	if(flag==4)
	{quan_kai();
		if(m==0)
		{
		Motor3_SetSpeed(-2500);//��
		Motor4_SetSpeed(-2500);//��
		sum_encode_left=0;
		sum_encode_right=0;
			m=1;
		}
    if(m==1)
    {
	 	 Motor3_SetSpeed(-3500);//��
		 Motor4_SetSpeed(-3500);//��
	   if(red_or_blue==1){what_ball=1;}
else if(red_or_blue==2){what_ball=0;}
     if((sum_encode_right>=2000&&sum_encode_left<=-2000))//if(y_ref_>160) ����Ŀ��Ȧ��
			{Motor3_SetSpeed(0);Motor4_SetSpeed(0); //��//��
			get_ball=0;flag=0;round_=2;m=0;possess=0;place=0;
			}
	  }
		  flag3=0;time3=0;//�������ӵִﰲȫ�����ٵ�ʱ��ͱ�־λ
	}
}
void Find_the_lost_ball(void)
{
	if(flag==5)
	{
//		 if(lose__flag==1)
//	  {
				
			 count_=1740;			/*PWM_DSetC4(count_);*/	PWM_DSetC2(count_);//����ͷ
		count_a = 2398-count_;PWM_DSetC4(count_a);
				if(round_==1&&red_or_blue==1)//���ӵ�һ��
					{
				    zizhuan_pid();
						if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&blue_==9&&(cross!=9)&&place!=1)//תһȦδ�ҵ���
						{
							what_ball=8;  flag = 8;//
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&blue_==9&&(go_red!=9&&cross==9)&&place!=2&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 6; flag = 26;
							
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&blue_==9&&(go_blue!=9&&cross==9)&&place!=3&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 7; flag = 27;
						}
						else if(blue_!=9/*&&losef==1*/)    
						{
							 what_ball=1;get_ball=0;flag=0;
						}
					}
		   if(round_==2&&red_or_blue==1)//���ӵڶ���
			    {
				    zizhuan_pid();
					  if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&blue_==9&&black_==9&&yellow_==9&&possess==0&&cross!=9&&place!=1)//תһȦδ�ҵ���
						{
               what_ball=8; flag = 8;//
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&blue_==9&&black_==9&&yellow_==9&&possess==0&&(go_red!=9&&cross==9)&&place!=2&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 6; flag = 26;
							
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&blue_==9&&black_==9&&yellow_==9&&possess==0&&(go_blue!=9&&cross==9)&&place!=3&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 7; flag = 27;
						}
						else   if((blue_!=9||black_!=9||yellow_!=9 )/*&&losef==1 */)                                                                               //תȦ�ڼ��ҵ�����
						{
							judge();flag=0;get_ball=0;
						}
						if(possess==1&&safe_blue!=9){flag=2;}
									
			    }
					
/****************************************************************************************************/
			 if(round_==1&&red_or_blue==2)//��ӵ�һ��
          {
			      zizhuan_pid();
						if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&red_==9&&cross!=9&&place!=1)//תһȦδ�ҵ���
						{
						  what_ball=8;	flag = 8;//
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&red_==9&&(go_red!=9&&cross==9)&&place!=2&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 6; flag = 26;
							
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&red_==9&&(go_blue!=9&&cross==9)&&place!=3&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 7; flag = 27;
						}	
						else  if(red_!=9/*&&losef==1*/) 
						{
							what_ball=0;get_ball=0;flag=0;
						}
				  }
			 if(round_==2&&red_or_blue==2)//��ӵڶ���
			    {	
			      zizhuan_pid();
					  if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&red_==9&&black_==9&&yellow_==9&&possess==0&&cross!=9&&place!=1)//תһȦδ�ҵ���
						{
              what_ball=8;  flag = 8;//
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&red_==9&&black_==9&&yellow_==9&&possess==0&&(go_red!=9&&cross==9)&&place!=2&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 6; flag = 26;
							
						}
						else if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&red_==9&&black_==9&&yellow_==9&&possess==0&&(go_blue!=9&&cross==9)&&place!=3&&y_safe>30)//תһȦδ�ҵ���
						{
							what_ball = 7; flag = 27;
						}	
						else   if((red_!=9||black_!=9||yellow_!=9 )/*&&losef==1*/ )                                                                               //תȦ�ڼ��ҵ�����
						{
							judge();flag=0;get_ball=0;
						}
						if(possess==1&&safe_red!=9){flag=2;}
			    }
//		}
/*****************************************************/
//		if(lose__flag==2)
//		{
//			flag=0;	get_ball=0;
//			if(round_==1)
//			{
//			  if(red_or_blue==1){what_ball=1;}
//			  if(red_or_blue==2){what_ball=0;}
//			}
//			if(round_==2){judge();}
//		}
	}
}


void find_ball(void)
{
//////////////////////////////////////////////
//	  count_=1740;
//    PWM_DSetC2(count_);//����ͷ//1500 1225
	 if(lose__flag==1)
	{
    count_=1740;
   PWM_DSetC2(count_);//����ͷ//1500 1225
		if(round_==2&&red_or_blue==1)//����
		{

						if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&blue_==9&&black_==9&&yellow_==9)//תһȦδ�ҵ���
					{
									if(go_blue==7)	
									{
										what_ball=7;
									}
									else if(go_red==6)
									{
										what_ball=6;
									}
					}
					else   if((blue_!=9||black_!=9||yellow_!=9 )&&losef==1 )                                                                               //תȦ�ڼ��ҵ�����
					{
						judge();
						flag=0;get_ball=0;
			
						
					}
		}
		
////		
	  if(round_==2&&red_or_blue==2)//���
		{
			if( (sum_encode_left<=-800&&sum_encode_right<=-800)&&red_==9&&black_==9&&yellow_==9)//תһȦδ�ҵ���
					{
			
									if(go_blue==7)	
									{
										what_ball=7;
									}
									else if(go_red==6)
									{
										what_ball=6;
									}			
					}
						else   if((red_!=9||black_!=9||yellow_!=9)  &&losef==1)                                                                               //תȦ�ڼ��ҵ�����
					{
						judge();
						flag=0;get_ball=0;
						
					}
		}
			
	}
	//////////////////////////////
		if(lose__flag==2)
		{
			flag=0;	get_ball=0;
			if(round_==1)
			{
			  if(red_or_blue==1){what_ball=1;}
			  if(red_or_blue==2){what_ball=0;}
			}
			if(round_==2){judge();}
		}
		////////////////////////////////////////////////////////////////
		if(lose__flag==3)
		{
//				
			    count_=1740;//1400-1740
   PWM_DSetC2(count_);//����ͷ//1500 1225
//			flag=2;FLAG=0;
		if(red_or_blue==1)//����
		{
			if( (sum_encode_left<=-1000&&sum_encode_right<=-1000)&&safe_blue==9)//תһȦδ�ҵ���
					{
					flag=2;

					}
					else   if( safe_blue!=9)                                                                               //תȦ�ڼ��ҵ�����
					{

						flag=2;
					}
		}
		}
//  	quekou_close();
		bihe();
	  zizhuan_pid();
	///
if(round_==1)
{
		if(red_!=9||black_!=9||yellow_!=9)
		{
			if(round_==1)
			{
				
					if(red_or_blue==2)//���
					{
					what_ball=0;//����
					}
//				if(
				  flag=0;
			   	get_ball=0;
			}
			if(round_==2)
			{
				judge();
			}
		}
		
		
		if(blue_!=9||black_!=9||yellow_!=9)
		{
			if(round_==1)
			{
				
					if(red_or_blue==1)//
					{
					what_ball=1;//
					}
		//		
		   		flag=0;
				  get_ball=0;
			}
			if(round_==2)
			{
				judge();
			}
		}
	}
	////////////////////////////////////
	///
}





 



/*
void judge(void)	 
{
	 if(yellow_==3)
	 {
		  what_ball=3;flag=0;get_ball=0;
	 }
	 
	 if(yellow_==9&&black_==2)
	 {
		  what_ball=2;flag=0;get_ball=0;
	 }
	 
if(red_or_blue==2)//red
{
	 if(yellow_==9&&black_==9&&red_==0)
	 {
		what_ball=0;flag=0;get_ball=0;
	 }
}
	 
if(red_or_blue==1)//blue
{
	 if(yellow_==9&&black_==9&&blue_==1)
	 {
		what_ball=1;flag=0;get_ball=0;
	 }
}	 
}
*/
void judge(void)	 
{
	 if(yellow_==3)
	 {
		  what_ball=3;flag=0;get_ball=0;
	 }
	 
	 if(yellow_==9&&black_==2)
	 {
		  what_ball=2;flag=0;get_ball=0;
	 }
	 
if(red_or_blue==2)//red
{
	 if(yellow_==9&&black_==9&&red_==0)
	 {
		what_ball=0;flag=0;get_ball=0;
	 }
}
	 
if(red_or_blue==1)//blue
{
	 if(yellow_==9&&black_==9&&blue_==1)
	 {
		what_ball=1;flag=0;get_ball=0;
	 }
}	 
}

void one_min(void)//�ں�
{
	if(black_==2)
	 {
		  what_ball=2;flag=0;get_ball=0;
	 }
	 
	 if(red_or_blue==2)//red
{
	 if(black_==9&&red_==0)
	 {
		what_ball=0;flag=0;get_ball=0;
	 }
}
	 
if(red_or_blue==1)//blue
{
	 if(black_==9&&blue_==1)
	 {
		what_ball=1;flag=0;get_ball=0;
	 }
}	 
}

void after_one_min(void)//�ڻƺ�
{
		 if(black_==2)
	 {
		  what_ball=2;flag=0;get_ball=0;
	 }
	 
	 if(black_==9&&yellow_==3)
	 {
		  what_ball=3;flag=0;get_ball=0;
	 }
	 
if(red_or_blue==2)//red
{
	 if(yellow_==9&&black_==9&&red_==0)
	 {
		what_ball=0;flag=0;get_ball=0;
	 }
}
	 
if(red_or_blue==1)//blue
{
	 if(yellow_==9&&black_==9&&blue_==1)
	 {
		what_ball=1;flag=0;get_ball=0;
	 }
}	 
	
	
}
void check(void)
{
	static int check_for=1;
	static int check_in=0;
		if(flag==6)
	{
/**************************************************round1**********************************/
     if(round_==1)
		 {
			if(red_or_blue==1)//blue round1
			{
				if(check_for==1)
				{
					if(blue_!=9&&red_==9&&yellow_==9&&black_==9&&check_flag==1)//��ȡ������
					 { 
						 check_in=3; check_for=2;
					 }
					 else if(blue_==9&&red_==9&&yellow_==9&&black_==9&&check_flag==1)//û��
					 {
						 	
						   if(jiaoluo_flag==1){check_in=6; check_for=2; }else{ check_in=2; check_for=2; }
					 }
				   else if((red_!=9||yellow_!=9||black_!=9)&&check_flag==1)//������
					 {
					
						
						   quan_kai();/*PWM_DSetC4(count_);*/
						 count_a = 2398-count_;PWM_DSetC4(count_a);
						  	Motor3_SetSpeed(-4000);//��
						    Motor4_SetSpeed(-4000);//��
						  if(jiaoluo_flag==1){check_in=6; check_for=2; 	 }else{ check_in=1; check_for=2; }
//						  check_in=1;
//						  check_for=2;
					 }		
				}
				if(check_for==2)
				{
					  if(back_flag==1&&check_in==1 )
						 {
							 get_ball=0; flag=0;		jiaoluo_flag=0;   count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==2){
							 get_ball=0; flag=0;		jiaoluo_flag=0;  count_a = 2398-count_;PWM_DSetC4(count_a); /*PWM_DSetC4(count_);*/
							  back_flag=0; 
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==3){
							  get_ball=1;  flag=2;lose=1;		jiaoluo_flag=0;  count_a = 2398-count_;PWM_DSetC4(count_a); /*PWM_DSetC4(count_);*/

							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }
						 else if(check_in==6){
							 jiaoluo_flag=0; flag=17;back_flag=0;   count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
							 
						 }
						 
						 
				}
			}	
			if(red_or_blue==2)//red  round1
			{
				if(check_for==1)
				{
					if(blue_==9&&red_!=9&&yellow_==9&&black_==9&&check_flag==1)//��ȡ������
					 {
						 check_in=3; check_for=2;  jiancha= 3;						 		
						 	 /**********************************************************/
							 /**********************************************************/
					 }
					 else if(blue_==9&&red_==9&&yellow_==9&&black_==9&&check_flag==1)//����ץ
					 {

						 
						 	if(jiaoluo_flag==1){check_in=6; check_for=2; jiancha= 6;}else{ check_in=2; check_for=2; jiancha= 5;}
					 }
				   else if((blue_!=9||yellow_!=9||black_!=9)&&check_flag==1)//�и���
					 {
						 
						    quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/
						  Motor3_SetSpeed(-4000);//��
						  Motor4_SetSpeed(-4000);//��
						 if(jiaoluo_flag==1){check_in=6; check_for=2;jiancha= 6; }else{ check_in=1; check_for=2; jiancha= 5;}
					 }		
				}
				if(check_for==2)
				{
					  if(back_flag==1&&check_in==1 )
						 {
							 get_ball=0; flag=0;jiaoluo_flag=0;  count_a = 2398-count_;PWM_DSetC4(count_a); /*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==2){
							 get_ball=0; flag=0;jiaoluo_flag=0; count_a = 2398-count_;PWM_DSetC4(count_a);  /* PWM_DSetC4(count_);*/
							  back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==3){
							  get_ball=1;  flag=2;lose=1;jiaoluo_flag=0; count_a = 2398-count_;PWM_DSetC4(count_a); /*PWM_DSetC4(count_);*/
							  back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }
						 	else if(check_in==6){
							 jiaoluo_flag=0; flag=17;back_flag=0; count_a = 2398-count_;PWM_DSetC4(count_a);  /*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
							 
						 }
				}
			}
		}
/**************************************************round2**********************************/
if(round_==2)///////
		{//
if(red_or_blue==2)//red  round2
			{
				if(check_for==1&&check_flag==1)
				{
						if(number==0)
						{           
						   if(jiaoluo_flag==1){    check_in=6; check_for=2;situation_=0; }  //flag=17
               else{ check_in=2; check_for=2;situation_=1;  }		 //    flag = 0
						}

						if(number==1)
						{
							if(blue_!=9){check_in=1; check_for=2;situation_=2;quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); } // �򿪺��� ->flag=0 
							if(blue_==9)
							{
								 if(red_!=9){check_in=3; check_for=2;situation_=3;bihe();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); } //�պϺ��� ->flag = 0
								 if(yellow_!=9||black_!=9){check_in=3; check_for=2;situation_=4;bihe();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); }    //  �պϺ��� -> ֱ���� ->flag = 0 
							} 

						}
						if(number==2||number==3)
						{
							 if(blue_!=9)// �򿪺��� ->flag=0 
							{
                  check_in=1; check_for=2;situation_=5; quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000);
							}
							if(blue_==9)
							{
								 if(yellow_!=9){   check_in=1; check_for=2;situation_=6;quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); }// �򿪺��� ->flag=0 
								 if(yellow_==9){   check_in=3; check_for=2;situation_=7;bihe();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); }// �պϺ��� ->ֱ����->flag=0 
							} 
							
						}

						if(number==4)// �򿪺��� ->flag=0 
						{
							 check_in=1; check_for=2;situation_=8; quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000);
						}
				}
				
/*************************************************************************/
				if(check_for==2)
				{
					  if(back_flag==1&&check_in==1 )
						 {
							 get_ball=0; flag=0;jiaoluo_flag=0;count_a = 2398-count_;PWM_DSetC4(count_a);   /*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==2){
							 get_ball=0; flag=0;jiaoluo_flag=0;count_a = 2398-count_;PWM_DSetC4(count_a);  /* PWM_DSetC4(count_);*/
							  back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==3&&back_flag==1)
						 {
							  get_ball=1;lose=1;possess=1;jiaoluo_flag=0;/*PWM_DSetC4(count_);*/count_a = 2398-count_;PWM_DSetC4(count_a);
							 	if(situation_==4||situation_==7){flag=10;}else{flag=2;}//ֱ����10���Ǽ�����ȫ������2
							  back_flag=0;
							  back_time=0;
							  check_in=0;
							  check_for=1;
						 }
//						 else if(check_in==5)
//						 {
//                    flag=10;get_ball=1;lose=1; possess=1;  jiaoluo_flag=0;  /* PWM_DSetC4(count_);*/
//							 		  check_in=0;check_for=1;back_flag=0;back_time=0;
//						 }
						 else if(check_in==6){
							 jiaoluo_flag=0; flag=17;back_flag=0; count_a = 2398-count_;PWM_DSetC4(count_a);  /*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
							 
						 }
				}
			}
/************************************************************************/
if(red_or_blue==1)//blue round2
			{
							if(check_for==1&&check_flag==1)
				{
						if(number==0)
						{           
						   if(jiaoluo_flag==1){check_in=6; check_for=2;situation_=0; }  //flag=17
               else{ check_in=2; check_for=2;situation_=1;  }		 //    flag = 0
						}

						if(number==1)
						{
							if(red_!=9){check_in=1; check_for=2;situation_=2;quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); } // �򿪺��� ->flag=0 
							if(red_==9)
							{
								 if(blue_!=9){check_in=3; check_for=2;situation_=3;bihe();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); } //�պϺ��� ->flag = 0
								 if(yellow_!=9||black_!=9){check_in=3; check_for=2;situation_=4;bihe();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); }    //  �պϺ��� -> ֱ���� ->flag = 0 
							} 

						}
						if(number==2||number==3)
						{
							 if(red_!=9)// �򿪺��� ->flag=0 
							{
                  check_in=1; check_for=2;situation_=5; quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000);
							}
							if(red_==9)
							{
								 if(yellow_!=9){   check_in=1; check_for=2;situation_=6;quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); }// �򿪺��� ->flag=0 
								 if(yellow_==9){   check_in=3; check_for=2;situation_=7;bihe();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000); }// �պϺ��� ->ֱ����->flag=0 
							} 
							
						}

						if(number==4)// �򿪺��� ->flag=0 
						{
							 check_in=1; check_for=2;situation_=8; quan_kai();count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/Motor3_SetSpeed(-4000); Motor4_SetSpeed(-4000);
						}
				}
/*************************************************************************/
					if(check_for==2)
				{
					  if(back_flag==1&&check_in==1 )
						 {
							 get_ball=0; flag=0;jiaoluo_flag=0; count_a = 2398-count_;PWM_DSetC4(count_a);  /*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==2){
							 get_ball=0; flag=0;jiaoluo_flag=0; count_a = 2398-count_;PWM_DSetC4(count_a);  /*PWM_DSetC4(count_);*/
							  back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
						 }else if(check_in==3&&back_flag==1)
						 {
							  get_ball=1;lose=1;possess=1;jiaoluo_flag=0;count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/
							 	if(situation_==4||situation_==7){flag=10;}else{flag=2;}//ֱ����10���Ǽ�����ȫ������2
							  back_flag=0;
							  back_time=0;
							  check_in=0;
							  check_for=1;
						 }
//						 else if(check_in==5)
//						 {
//                    flag=10;get_ball=1;lose=1; possess=1;  jiaoluo_flag=0;   PWM_DSetC4(count_);
//							 		  check_in=0;check_for=1;back_flag=0;back_time=0;
//						 }
						 else if(check_in==6){
							 jiaoluo_flag=0; flag=17;back_flag=0;  count_a = 2398-count_;PWM_DSetC4(count_a); /*PWM_DSetC4(count_);*/
							 back_flag=0;
							 back_time=0;
							 check_in=0;
							 check_for=1;
							 
						 }
				}
			}
		}
	}
}

void Look_for_the_cross(void)
{
	if(flag==8)
	{
	count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
					/*PWM_DSetC4(count_);*/	
  PWM_DSetC2(count_);//����ͷ//1500 1225
	PID_action_Safe(160,70);
	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
	if(lose==1)//��ʧ����ʮ�ּ�Ŀ����ת
	{
					zizhuan_pid();
		
		      spot_the_ball();

//						if(round_==1)
//				{
//					if(red_or_blue==1)//����
//					{
//						if(blue_!=9)
//						{
//							what_ball = 1;flag=5;get_ball=0;
//						}
//					}
//					else
//					{
//						if(red_!=9)
//						{
//							what_ball = 0;flag=5;get_ball=0;
//						}
//					}
//				}
//				
//			/****************************************************************************/
//					if(round_==2)
//				{
//					if(red_or_blue==1)//����
//					{
//						if(blue_!=9||black_!=9||yellow_!=9)
//						{
//							 flag=5;get_ball=0;judge();
//						}
//					}
//					else
//					{
//						if(red_!=9||black_!=9||yellow_!=9)
//						{
//							 flag=5;get_ball=0;judge();
//						}
//					}
//				}
	}
	/***/
	if(y_ref<=100&&cross_flag==1)    //flag2��ʾʶ��ȫ������2��  80
	 {
		 flag=9;cross_flag=0;find_cross_time=0;sum_encode_left=0;sum_encode_right=0;lose__flag=1;
	 }

}
}

void go_ahead(void)
{
	if(flag == 9)
	{
				Motor3_SetSpeed(3500);//��
		    Motor4_SetSpeed(3500);//��
				if(sum_encode_left>1150&&sum_encode_right<-1150)
				{
				   flag=5;get_ball=0;kasi_flag=0;place=1;sum_encode_left=0;sum_encode_right=0;
				}
	}
}

void get_three_balls(void)
{
	if(flag==10)
	{

			count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
					/*PWM_DSetC4(count_);*/	
      PWM_DSetC2(count_);//����ͷ//1500 1225
		
		  if(red_or_blue==1){what_ball=5;}//����//����ȫ��
			if(red_or_blue==2){what_ball=4;}//���//�찲ȫ��
		  PID_action_Safe(160,70);
		  Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
		  Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
		
		  if(lose==1){zizhuan_pid();}//��ʧ��ȫ��Ŀ����ת
      if(y_ref<=80&&flag2==1)    //flag2��ʾʶ��ȫ������2��
		  {
	     time3=0;                  //���ڼ����ӵִﰲȫ�����ٵ�ʱ��
			 flag=3;
		  }
	}
}
void  to_center_than_to_red_go(void)
{
	if(flag == 14)
	{
	what_ball=8;
	count_=1740;  count_a = 2398-count_;PWM_DSetC4(count_a);
					/*PWM_DSetC4(count_);*/
  PWM_DSetC2(count_);//����ͷ//1500 1225
	PID_action_Safe(160,70);
	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
	if(lose==1)//��ʧ����ʮ�ּ�Ŀ����ת
	{
		zizhuan_pid();
	}
		if(y_ref<=80&&cross_flag==1)    //flag2��ʾʶ��ȫ������2��
	 {
		 flag=15;cross_flag=0;find_cross_time=0;sum_encode_left=0;sum_encode_right=0;
	 }
 }
}
void go_ahead_red(void)
{
	if(flag == 15)
	{
				Motor3_SetSpeed(3500);//��
		    Motor4_SetSpeed(3500);//��
				if(sum_encode_left>1150&&sum_encode_right<-1150)
				{
				   flag=16;get_ball=0;place=1;
				}
	}
}
void to_red_go(void)
{
	if(flag== 16)
	{
		what_ball=6;
		count_=1740;  count_a = 2398-count_;PWM_DSetC4(count_a);
					/*PWM_DSetC4(count_);*/	
    PWM_DSetC2(count_);//����ͷ//1500 1225
	  PID_action_Safe(160,50);
	  Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
	  Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
		if(lose==1)//��ʧ����ʮ�ּ�Ŀ����ת
		{
		   zizhuan_pid();
		}
		if(y_ref<=60)    //flag2��ʾʶ��ȫ������2��
		{
		 flag=5;go_red_flag=0;//cross_flag=0;find_cross_time=0;sum_encode_left=0;sum_encode_right=0;
			 Motor3_SetSpeed(0);//��
	     Motor4_SetSpeed(0);//��
	  }
	}
}




void  to_center_than_to_blue_go(void)
{
	if(flag == 17)
	{
	what_ball=8;
	count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
					/*PWM_DSetC4(count_);*/	
  PWM_DSetC2(count_);//����ͷ//1500 1225
	PID_action_Safe(160,70);
	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
		if(y_ref<=80&&cross_flag==1)    //flag2��ʾʶ��ȫ������2��
	 {
		 flag=18;cross_flag=0;find_cross_time=0;sum_encode_left=0;sum_encode_right=0;
	 }
 }
}

void go_ahead_blue(void)
{
	if(flag == 18)
	{
				Motor3_SetSpeed(3500);//��
		    Motor4_SetSpeed(3500);//��
				if(sum_encode_left>1150&&sum_encode_right<-1150)
				{
				   flag=19;get_ball=0;place=1;
				}
	}
}
void to_blue_go(void)
{
	if(flag== 19)
	{
		what_ball=7;
		count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
					/*PWM_DSetC4(count_);*/	
    PWM_DSetC2(count_);//����ͷ//1500 1225
	  PID_action_Safe(160,50);
	  Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
	  Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
		if(y_ref<=60)    //flag2��ʾʶ��ȫ������2��
	 {
		 flag=5;//cross_flag=0;find_cross_time=0;sum_encode_left=0;sum_encode_right=0;
	 }
	}
}

void  grab_the_ball_safe(void)
{
	if(flag==14)
	{
		//if(situation==1)
		//{
			if(situation==10||situation==12)//blue �����������ں찲ȫ���ұ� ->ȥ�������
			{
				count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
							/*PWM_DSetC4(count_);*/	
        PWM_DSetC2(count_);//����ͷ//1500 1225
	      PID_action_Safe(160,50);
      	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
       	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
				if(lose==1){zizhuan_pid();spot_the_ball();zizhuan_flag=2;}
				if(y_ref<=65)    //�������ֵĳ�������
	      {
		       flag=15;place=2;
	      }
			}
			if(situation==3||situation==2)//blue �췽������������ȫ���ұ� ->ȥ��������
			{
				count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
							/*PWM_DSetC4(count_);*/	
        PWM_DSetC2(count_);//����ͷ//1500 1225
	      PID_action_Safe(160,50);
      	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
       	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
				if(lose==1){zizhuan_pid();spot_the_ball();zizhuan_flag=2;}
				if(y_ref<=65)    //�������ֵĳ�������
	      {
		         flag=15;place=3;
	      }
			}
			
						if(situation==8||situation==6)//blue �췽������������ȫ���ұ� ->ȥ��������
			{
				count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
							/*PWM_DSetC4(count_);*/	
        PWM_DSetC2(count_);//����ͷ//1500 1225
	      PID_action_Safe(160,50);
      	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
       	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
				if(lose==1){re_zizhuan_pid();spot_the_ball();zizhuan_flag=2;}
				if(y_ref<=65)    //�������ֵĳ�������
	      {
		         flag=15;place=2;
	      }
			}
			
						if(situation==14||situation==15)//blue �췽������������ȫ���ұ� ->ȥ��������
			{
				count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a);
							/*PWM_DSetC4(count_);*/	
        PWM_DSetC2(count_);//����ͷ//1500 1225
	      PID_action_Safe(160,50);
      	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
       	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
				if(lose==1){re_zizhuan_pid();spot_the_ball();zizhuan_flag=2;}
				if(y_ref<=65)    //�������ֵĳ�������
	      {
		         flag=15;place=3;
	      }
			}
	
		
	}
}
void spot_the_ball(void)
{
	
	
	if(kasi_flag==0){}
	if(kasi_flag==1){
		if(round_==1)
				{
					if(red_or_blue==1)//����
					{
						if(blue_!=9)
						{
							what_ball = 1;flag=5;get_ball=0;
						}
					}
					else
					{
						if(red_!=9)
						{
							what_ball = 0;flag=5;get_ball=0;
						}
					}
				}
				
			/****************************************************************************/
					if(round_==2)
				{
					if(red_or_blue==1)//����
					{
						if(blue_!=9||black_!=9||yellow_!=9)
						{
							 flag=5;get_ball=0;judge();
						}
					}
					else
					{
						if(red_!=9||black_!=9||yellow_!=9)
						{
							 flag=5;get_ball=0;judge();
						}
					}
				}
			}
	
}
//1050  1070  1500
void go_zone_find_ball(void)
{
		if(flag==15)
	{
//		 if(lose__flag==1)
//	  {
		
			 count_=1740;PWM_DSetC2(count_);	count_a = 2398-count_;PWM_DSetC4(count_a);		/*PWM_DSetC4(count_);*/	//����ͷ
				if(round_==1&&red_or_blue==1)//���ӵ�һ��
					{
						if(situation==6||situation==8||situation==14||situation==15){zizhuan_pid();}
		      	if(situation==2||situation==3||situation==10||situation==12){re_zizhuan_pid();}
            if(blue_!=9/*&&losef==1*/)    
						{
							 what_ball=1;get_ball=0;flag=0;situation=0;
						}
					}
		   if(round_==2&&red_or_blue==1)//���ӵڶ���
			    {
						if(situation==6||situation==8||situation==14||situation==15){zizhuan_pid();}
		      	if(situation==2||situation==3||situation==10||situation==12){re_zizhuan_pid();}
           if((blue_!=9||black_!=9||yellow_!=9 )/*&&losef==1*/ )                                                                               //תȦ�ڼ��ҵ�����
						{
							judge();flag=0;get_ball=0;situation=0;
						}
						if(possess==1&&safe_blue!=9){flag=2;}
									
			    }
					
/****************************************************************************************************/
			 if(round_==1&&red_or_blue==2)//��ӵ�һ��
          {
						if(situation==6||situation==8||situation==14||situation==15){zizhuan_pid();}
		      	if(situation==2||situation==3||situation==10||situation==12){re_zizhuan_pid();}

						 if(red_!=9/*&&losef==1*/) 
						{
							what_ball=0;get_ball=0;flag=0;situation=0;
						}
				  }
			 if(round_==2&&red_or_blue==2)//��ӵڶ���
			    {	
						if(situation==6||situation==8||situation==14||situation==15){zizhuan_pid();}
		      	if(situation==2||situation==3||situation==10||situation==12){re_zizhuan_pid();}

						 if((red_!=9||black_!=9||yellow_!=9 )/*&&losef==1*/ )                                                                               //תȦ�ڼ��ҵ�����
						{
							judge();flag=0;get_ball=0;situation=0;
						}
						if(possess==1&&safe_red!=9){flag=2;}
			    }
	}
}


void jiaoluo_addres(void)
{
	if(flag==17)
	{
					 bihe();
	if(m==0)
		{
		Motor3_SetSpeed(-2500);//��
		Motor4_SetSpeed(-2500);//��
		sum_encode_left=0;
		sum_encode_right=0;
			m=1;
		}
    if(m==1)
    {
	 	 Motor3_SetSpeed(-4000);//��
		 Motor4_SetSpeed(-4000);//��
     if((sum_encode_right>=1000&&sum_encode_left<=-1000)||jiaoluo_addres_time>25)//if(y_ref_>160) ����Ŀ��Ȧ��
			{Motor3_SetSpeed(0);Motor4_SetSpeed(0); //��//��
         m=0;  PWM_DSetC4(1300);flag=18;count_=1740;PWM_DSetC2(count_);//����ͷ  //���²�̧ͷ
			}
	  }
	}
}


void qianjin_jiaoluo(void)
{
	if(flag==18)
	{
		PID_action(144,83);
		Motor3_SetSpeed(+X_pid.out-Y_pid.out);//��
		Motor4_SetSpeed(-X_pid.out-Y_pid.out);//��
	 	 if(lose==1){zizhuan_pid();}
		 	if(y_ref<=115)
			{  count_-=7;if(count_<1550){count_=1550;}}
			if(y_ref>=180)
			{	 count_+=7;if(count_>=1740){count_=1740;}}
			 PWM_DSetC2(count_);
			if(((count_<1600)&&((x_ref<=152)&&(x_ref>=136))&&((y_ref<=90)&&(y_ref>=70)))||houtui_time>=25)//�Ѿ�����Ŀ����Ȼ���צ�ӣ�flag0��1
			{
				flag=19;
			}
		 
	}
}
void qianjin_little(void)
{
	if(flag==19)
	{
	if(m==0)
		{
		Motor3_SetSpeed(2500);//��
		Motor4_SetSpeed(2500);//��
		sum_encode_left=0;
		sum_encode_right=0;
			m=1;
		}
    if(m==1)
    {
	 	 Motor3_SetSpeed(2500);//��
		 Motor4_SetSpeed(2500);//��
     if(((sum_encode_right<=-800&&sum_encode_left>=+800))||HOUTUI_TIME>=25)//if(y_ref_>160) ����Ŀ��Ȧ��
			{Motor3_SetSpeed(0);Motor4_SetSpeed(0); //��//��
         m=0;  PWM_DSetC4(1200);flag=20;
				count_=1740;PWM_DSetC2(count_);
			}
	  }
	}
}
//2375-2250
void re_houtui(void)
{
	if(flag==20)
	{
		PWM_DSetC4(1300);
			if(m==0)
		{
		Motor3_SetSpeed(-2500);//��
		Motor4_SetSpeed(-2500);//��
		sum_encode_left=0;
		sum_encode_right=0;
			m=1;
		}
    if(m==1)
    {
	 	 Motor3_SetSpeed(-4000);//��
		 Motor4_SetSpeed(-4000);//��
     if((sum_encode_right>=500&&sum_encode_left<=-500)||re_houtui_time>15)//if(y_ref_>160) ����Ŀ��Ȧ��
			{Motor3_SetSpeed(0);Motor4_SetSpeed(0); //��//��
         m=0; PWM_DSetC4(700); get_ball=0;//����ͷ
			   flag=21; 
			}
	  }
	}
}

void stop(void)
{
	if(flag==21)
	{
		 Motor3_SetSpeed(-0);//��
		 Motor4_SetSpeed(-0);//��
		if(stop_time==5)
		{
			flag=22;
		}
	}
}

void zhangzhua_back(void)
{
	if(flag==22)
	{
		bihe();
			if(m==0)
		{
		Motor3_SetSpeed(-4000);//��
		Motor4_SetSpeed(-4000);//��
		sum_encode_left=0;
		sum_encode_right=0;
			m=1;
		}
    if(m==1)
    {
	 	 Motor3_SetSpeed(-4000);//��
		 Motor4_SetSpeed(-4000);//��
     if((sum_encode_right>=800&&sum_encode_left<=-800)||zhangzhua_back_time>25)//if(y_ref_>160) ����Ŀ��Ȧ��
			{Motor3_SetSpeed(0);Motor4_SetSpeed(0); //��//��
         m=0;  PWM_DSetC4(700); count_=1740;PWM_DSetC2(count_);get_ball=0;//����ͷ
			    //	quekou_close();
				bihe();lenque_time=0; k_f=1;
				if(dis>200000){flag=50;}
				else{flag=0;}
					
			}
	  }
	}
}

void go_red_go(void)
{
	if(flag==26)
	{
		count_=1740;
  PWM_DSetC2(count_);count_a = 2398-count_;PWM_DSetC4(count_a);			/*PWM_DSetC4(count_);*/	//����ͷ//1500 1225
	PID_action_Safe(160,50);
	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
	if(lose==1)//��ʧ����ʮ�ּ�Ŀ����ת
	{
		if(zizhuandir_red%2==0){	zizhuan_pid();}
		if(zizhuandir_red%2!=0){	re_zizhuan_pid();}
		if((safe_red!=9||safe_blue!=9)&&y_safe<30){flag=5;}
		      spot_the_ball();
		      if(cross!=9){flag=5;}
	}
	if(y_ref<=80&&go_red_flag==1)    //flag2��ʾʶ��ȫ������2��  80
	 {
		 flag=30;sum_encode_left=0;sum_encode_right=0;lose__flag=1;place=2;go_red_flag=0;find_go_red_time=0;zizhuandir_red+=1;
	 }
	}
}

void go_blue_go(void)
{
	if(flag==27)
	{
	count_=1740;
  PWM_DSetC2(count_);		count_a = 2398-count_;PWM_DSetC4(count_a);	/*PWM_DSetC4(count_);*/	//����ͷ//1500 1225
	PID_action_Safe(160,50);
	Motor3_SetSpeed(+X_safe_pid.out-Y_safe_pid.out);//��
	Motor4_SetSpeed(-X_safe_pid.out-Y_safe_pid.out);//��
	if(lose==1)//��ʧ����ʮ�ּ�Ŀ����ת
	{
		if(zizhuandir_blue%2==0){	zizhuan_pid();}
		if(zizhuandir_blue%2!=0){	re_zizhuan_pid();}spot_the_ball();
		if((safe_red!=9||safe_blue!=9)&&y_safe<30){flag=5;}
		      if(cross!=9){flag=5;}
	}
	if(y_ref<=80&&go_blue_flag==1)    //flag2��ʾʶ��ȫ������2��  80
	 {
		 flag=31;sum_encode_left=0;sum_encode_right=0;lose__flag=1;place=3;go_blue_flag=0;find_go_blue_time=0;zizhuandir_blue+=1;
	 }
	}
}


void go_ahead_red_(void)
{
	if(flag == 30)
	{
				Motor3_SetSpeed(3500);//��
		    Motor4_SetSpeed(3500);//��
				if((sum_encode_left>1150&&sum_encode_right<-1150)||go_ahead_red_time>15)
				{
				   flag=5;get_ball=0;kasi_flag=0;place=2;sum_encode_left=0;sum_encode_right=0;
				}
	}
}

void go_ahead_blue_(void)
{
	if(flag == 31)
	{
				Motor3_SetSpeed(3500);//��
		    Motor4_SetSpeed(3500);//��
				if((sum_encode_left>1150&&sum_encode_right<-1150)||go_ahead_blue_time>15)
				{
				   flag=5;get_ball=0;kasi_flag=0;place=3;sum_encode_left=0;sum_encode_right=0;
				}
	}
}


void zhuaqiu_back(void)
{
	if(flag==33)
	{
		 count_=1740;count_a = 2398-count_;PWM_DSetC4(count_a); /*PWM_DSetC4(count_);*/PWM_DSetC2(count_);
			if(m==0)
		{
		Motor3_SetSpeed(-4000);//��
		Motor4_SetSpeed(-4000);//��
		sum_encode_left=0;
		sum_encode_right=0;
			m=1;
		}
    if(m==1)
    {
	 	 Motor3_SetSpeed(-4000);//��
		 Motor4_SetSpeed(-4000);//��
     if((sum_encode_right>=500&&sum_encode_left<=-500)||zhuaqiu_back_time>15)//if(y_ref_>160) ����Ŀ��Ȧ��
			{Motor3_SetSpeed(0);Motor4_SetSpeed(0); //��//��
         m=0; get_ball=0;//����ͷ
			   flag=2; //	quekou_close();
				bihe();
			}
	  }
	}
}


  void f40_back(void)
{
	if(flag==40)
	{
		 count_=1740; count_a = 2398-count_;PWM_DSetC4(count_a);/*PWM_DSetC4(count_);*/PWM_DSetC2(count_);
			if(m==0)
		{
		Motor3_SetSpeed(-4000);//��
		Motor4_SetSpeed(-4000);//��
		sum_encode_left=0;
		sum_encode_right=0;
			m=1;
		}
    if(m==1)
    {
	 	 Motor3_SetSpeed(-4000);//��
		 Motor4_SetSpeed(-4000);//��
     if((sum_encode_right>=500&&sum_encode_left<=-500)||hou_time>15)//if(y_ref_>160) ����Ŀ��Ȧ��
			{Motor3_SetSpeed(0);Motor4_SetSpeed(0); //��//��
         m=0; get_ball=0;//����ͷ
			   flag=5; //	quekou_close();
				bihe();lose=1;
			}
	  }
	}
}

void f50_zhuan(void)
{
	if(flag==50)
	{
		zizhuan_pid();
		if(f50_time==25){flag=0;}
	}
}

