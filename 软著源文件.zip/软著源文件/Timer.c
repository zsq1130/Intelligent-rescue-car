#include "timer.h"
#include "OLED.h"
#include "Encoder.h"
#include "string.h"
#include "stdio.h"
#include "PID.h"
#include "procedure.h"
#include "Motor.h"
#include "SYS.h"    //ϵͳ����
#include "delay.h" //PS2�ֱ�
#include "Serial.h"
/*********************����ı���****************/
int team=1,time2,flag2=0;//prevent flag==3
int time3,flag3=0;     //prevent flag==4
int round_ = 1;
int ment=1;
int lose=0; 
int time=0;
int32_t sum_encode_left;
int32_t sum_encode_right;
int check_time=0,check_flag=0;
int back_time=0,back_flag=0;
int cross_flag,find_cross_time;
int find_go_blue_time,go_blue_flag;
int find_go_red_time,go_red_flag;
int _3_min;
int hou_time,HOUTUI_TIME,stop_time;
int last_flag,last_last_flag;
int trig_flag=0,time7,echo_flag=0,echo_time=0,echo,last_echo,dis;
int distance ;
int i_;
int kasi_flag=0;
int get_ball_time,get_ball_flag;
int safe_time,get_safe_time_flag;
int kasi_time;
int jiaoluo_flag,jiaoluo_time;
int get_time,get_ball_flag;
int zizhuan_flag;
int defend_time,defend_flag,zhangzhua_back_time;
int go_ahead_red_time,go_ahead_blue_time;
int houtui_time=0,f40_time;
int lenque_time=150,f50_time;
/*********************EXTERN*******************/
extern int aaaaaaa;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6)
   {
		 
		 
/********************************************************************/
		 Speed_Left=Encoder3_GetSpeed();
		 Speed_Right=Encoder4_GetSpeed();
     sum_encode_left +=Speed_Left;////-
     sum_encode_right+=Speed_Right;////+
		 if(x_ref!=0&&y_ref!=0&&get_ball==0&&flag==0){Get_close_to_the_target_ball(); }
		 if(flag==1){Grab_the_target_ball();}
		 if((get_ball==1&&flag==2&&count_>=1000)||possess==1){Go_to_the_safe_zone();Spot_the_ball_halfway_through();}
		 if(flag==3){Towards_the_safety_zone();}
		 if(flag==4){Exit_the_safe_zone();}
		 if(flag==5){Find_the_lost_ball();}
		 if(flag==6){check();}	
	   if(flag==8){Look_for_the_cross();}
     if(flag==9){go_ahead();}
		 /*********************************/
		 //ǿ������ȫ��
		 if(flag==10){get_three_balls();}
		 /*********************************/
		 //������
		 if(flag==13){after_kasi_jiaoluo();}
//		 /*********************************/
     if(flag==14){grab_the_ball_safe();}
		 if(flag==15) {go_zone_find_ball();}
//		  if(flag==33){zhuaqiu_back();}
		 /*************************������********************************/
		 re_houtui();qianjin_jiaoluo(); jiaoluo_addres();qianjin_little();stop();zhangzhua_back();
     /***************************************************************/
     go_blue_go();  go_red_go();  go_ahead_red_(); go_ahead_blue_();
		 if(flag==40){f40_back();}
		 f50_zhuan();
		if(red_or_blue==1)//blue
		{
		 if(flag==2&&possess==1&&safe_blue!=9){flag=10;}
		}
		if(red_or_blue==2)//red
		{
		 if(flag==2&&possess==1&&safe_red!=9){flag=10;}
		}
		 
		 
		 
		
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
/*************************************************************/
		 if(last_flag == flag){defend_time++;if(defend_time==1500){what_ball=8;flag=5;sum_encode_right=0;sum_encode_left=0;}}
		 else{defend_time=0;} 
		 
//		 _3_min++;
//		 
      last_flag = flag;
		 
//      PID_action_ANGLE(90.0);
   }
	 if (htim->Instance == TIM2)
 {
	 	sprintf(temp,"%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",flag,what_ball,(int)x_ref,(int)y_ref,x_safe,y_safe,dis,(int)count_,distance,situation,place,jiaoluo_flag,place,yellow_);	  	                        //�����ͨ��
    HAL_UART_Transmit(&huart5,(uint8_t *)temp,strlen(temp),50);  
    sprintf(temp,"%d", (int)what_ball);		  	                        //������ͷͨ��
    HAL_UART_Transmit(&huart4,(uint8_t *)temp,strlen(temp),50);

	 		 _3_min++;
		 
//	 		adc1=get_adc_val(&hadc1)*100;
//		  adc2=get_adc_val(&hadc2)*100;
	 

	 
if(flag==17){jiaoluo_addres_time++;}else{jiaoluo_addres_time=0;} 	  
if(flag==18){houtui_time++;}else{houtui_time=0;} 	 
if(flag==19){HOUTUI_TIME++;}else{HOUTUI_TIME=0;} 	 
if(flag==22){zhangzhua_back_time++;}else{zhangzhua_back_time=0;} 	 
if(flag==21){stop_time++;}else{stop_time=0;}		 
if(flag==20){re_houtui_time++;}else{re_houtui_time=0;}		 
if(flag==30){ go_ahead_blue_time++;}else{go_ahead_blue_time=0;}
if(flag==31){ go_ahead_red_time++;}else{go_ahead_red_time=0;}
if(flag==33){ zhuaqiu_back_time++;}else{zhuaqiu_back_time=0;}	 
if(flag==40){ hou_time++;}else{hou_time=0;}	 	 
if(flag==50){ f50_time++;}else{	 	 f50_time=0;}	 
	 
/***ȥ��������ȫ***/
if((what_ball==6||what_ball==7)&&dis>300000&&distance<175000&&(go_red!=9||go_blue!=9)&&(safe_blue!=9||safe_red!=9))
{
	what_ball=8;  flag = 8;
}
	 
	 
	 
/****************ץ���ʱ************/	 	 

if((flag==0||flag==1)&&distance<190000&&(safe_blue!=9||safe_red!=9)&&count_>=1640)//01 ���� �����ⰲȫ��
{
   if(y_ref>y_safe)//���ڰ�ȫ��ǰ��
	 {
		   if(safe_blue!=9)
			 {
				 	if(x_ref>x_safe)//��������ȫ���ұ�
					{
						if(place==0){	lose = 1;	flag=8;what_ball=8;sum_encode_left=0;sum_encode_right=0;situation=1;}
						else	if(place==1){lose = 1;flag=14;what_ball=7;situation=2;}
						else  if(place==2){lose = 1;flag=14;what_ball=7;situation=3;}
						else	if(place==3){situation=4;}
						
					}
					if(x_ref<x_safe)//��������ȫ�����
					{
						if(place==0){lose = 1;	flag=8;what_ball=8;sum_encode_left=0;sum_encode_right=0;situation=1;situation=5;}
						else	if(place==1){lose = 1;flag=14;what_ball=6;situation=6;}
						else  if(place==2){situation=7;}
						else	if(place==3){lose = 1;flag=14;what_ball=6;situation=8;}
					}
			 }
				if(safe_red!=9)
			{
					if(x_ref>x_safe)//���ں찲ȫ���ұ�
					{
						if(place==0){lose = 1;	flag=8;what_ball=8;sum_encode_left=0;sum_encode_right=0;situation=1;situation=9;}
						else	if(place==1){lose = 1;flag=14;what_ball=6;situation=10;}
						else  if(place==2){situation=11;}
						else	if(place==3){lose = 1;flag=14;what_ball=6;situation=12;}
						
					}
					if(x_ref<x_safe)//���ں찲ȫ�����
					{
						if(place==0){lose = 1;	flag=8;what_ball=8;sum_encode_left=0;sum_encode_right=0;situation=13;}
						else	if(place==1){lose = 1;flag=14;what_ball=7;situation=14;}
						else  if(place==2){lose = 1;flag=14;what_ball=7;situation=15;}
						else	if(place==3){situation=16;}
						
					}
			}
	 }
	 if(y_ref<y_safe)//���ڰ�ȫ��ǰ��
	 {
	 }
}	
/**/
if((flag==0||flag==1)&&dis<235000&&(red_!=9||blue_!=9||black_!=9||yellow_!=9)&&safe_blue==9&&safe_red==9)//01 ���� ����  �ް�ȫ��
{
	 jiaoluo_time++;
	if(jiaoluo_time==60)//6S
	{
		jiaoluo_flag=1;flag=13;sum_encode_left=0;sum_encode_right=0;kasi_flag=1;
	}
}	


if((flag==0||flag==1)&&distance<131000&&(red_!=9||blue_!=9||black_!=9||yellow_!=9)&&(safe_blue!=9||safe_red!=9)&&count_<=1713&&count_>=1550)//01 ���� ����  �а�ȫ��
{
   f40_time++;if(f40_time==60){flag=40;}
}	
else{f40_time=0;}
if(flag==14||flag==8)//�����Һ����꿪ʼ��ʱ
{
	kasi_time++;if(kasi_time==15){kasi_flag=1;}
}	
else{kasi_time=0;kasi_flag=0;}

//if((flag==0||flag==1)&&distance<235000&&(safe_blue!=9||safe_red!=9))//01 ���� �����ⰲȫ��
//{
//	 get_ball_time++;
//	if(get_ball_time==100)//5S
//	{
//		get_ball_flag=1;flag=11;sum_encode_left=0;sum_encode_right=0;kasi_flag=1;
//	}
//}	
//	 
//if((flag==0||flag==1)&&(safe_blue!=9||safe_red!=9)&&red_==9&&blue_==9&&black_==9&&yellow_==9&&go_blue==9&&go_red==9)//��ץ��ʱֻ������ȫ�����ҳ���5��
//{
//	 safe_time++;
//	if(safe_time==100)
//	{
//		get_safe_time_flag=1;flag=11;sum_encode_left=0;sum_encode_right=0;
//	}
//}
//else{safe_time=0;}

/********************���빫ʽ*******************/
dis=-201927+321.7*count_+764*y_ref-0.1738*count_*count_-0.7542*count_*y_ref-1.2465*y_ref*y_ref;
distance=-201927+321.7*count_+764*y_safe-0.1738*count_*count_-0.7542*count_*y_safe-1.2465*y_safe*y_safe;
dis = -dis;
distance = -distance;

/****************���ñ���************/	 
	 if(flag!=0&&flag!=1){time_task1_flag=0;}
	 if(flag==0||flag==1){time_task1++;
	 if(time_task1==200){time_task1_flag=1;}}
	 
/*****************���״̬*************/	 
	 if(flag==6)
	 {
     check_time++;if(check_time==20){check_flag=1;}		
	 }
	 	if(flag==6&&check_flag==1)
	 {
		 back_time++;if(back_time==12){back_flag=1;}	if(back_time<12){count_=1740;PWM_DSetC2(count_);/*PWM_DSetC4(count_);*/count_a = 2398-count_;PWM_DSetC4(count_a);}			
	 }
/*******************�Ҳ������ʱ**************/
if(red_or_blue==1)
{
	 if(lose__flag==1&&(blue_!=9||black_!=9||yellow_!=9  )  )
	 {
		 lose_time++;
		 if(lose_time==4)
		 {
			 losef=1;
		 }
	 }
	 else
			{
				lose_time=0;losef=0;
			}
}
else
{
			
	if(lose__flag==1&&(red_!=9||black_!=9||yellow_!=9  )  )
	 {
		 lose_time++;
		 if(lose_time==4)
		 {
			 losef=1;
		 }
	 }
	 else
			{
				lose_time=0;losef=0;
			}
}
/**************************��ʧ��־λ**********************//*0 6 7 1 2 3 4 5 8*/

if(red_!=9){get_time++;if(get_time==7){get_ball_flag=1;}}
else{get_time=0;}

if(blue_!=9){get_time++;if(get_time==7){get_ball_flag=1;}}
else{get_time=0;}

if(black_!=9){get_time++;if(get_time==7){get_ball_flag=1;}}
else{get_time=0;}

if(yellow_!=9){get_time++;if(get_time==7){get_ball_flag=1;}}
else{get_time=0;}

if(what_ball==0)
{
	if(red_==9){time++;if(time==7){lose=1;}}
	else{time=0;lose=0;}
}
if(what_ball==6)
{
	 if(go_red==9){time++;if(time==7){lose=1;}		}
	 else{time=0;lose=0;}
}	
if(what_ball==7)
{
	 if(go_blue==9){time++;if(time==7){lose=1;}}
	 else{time=0;lose=0;}
}
if(what_ball==1)//blue	 
{
	 if(blue_==9){time++;if(time==7){lose=1;}}
	 else{time=0;lose=0;}
} 
if(what_ball==2)
{
	 if(black_==9){time++;if(time==7){lose=1;}}
	 else{time=0;lose=0;}
}
if(what_ball==3)
{
	 if(yellow_  ==9){time++;if(time==7){lose=1;}}
	 else{time=0;lose=0;}
}
if(what_ball==4)
{
	 if(safe_red ==9){time++;if(time==7){lose=1;}}
	 else{time=0;lose=0;}
}	
if(what_ball==5)
{
	 if(safe_blue ==9){time++;if(time==7){lose=1;}}
	 else{time=0;lose=0;}
}	
if(what_ball==8)
{
	 if(cross==9){time++;if(time==7){lose=1;}}
	 else{time=0;lose=0;}
}
/************************����������ȫ����cross��ʶ��ʱ**************************/
if(what_ball==6)
{
	if(go_red != 9)
		{
			find_go_red_time++;
			if(find_go_red_time==20) //!!!!!!!!>20?
			{
			   go_red_flag=1;
			}
		}
}
if(what_ball==7)
{
	if(go_blue != 9)
		{
			find_go_blue_time++;
			if(find_go_blue_time==20) //!!!!!!!!>20?
			{
			   go_blue_flag=1;
			}
		}
}	

//if(what_ball==7||what_ball==6)
//{
//	if(go_blue != 9||go_red!=9)
//		{
//			find_go_blue_time++;
//			if(find_go_blue_time==20) //!!!!!!!!>20?
//			{
//			   go_blue_flag=1;
//			}
//		}
//}	


if(what_ball==8)
{
	if(cross != 9)
		{
			find_cross_time++;
			if(find_cross_time==20) //!!!!!!!!>20?
			{
			   cross_flag=1;
			}
		}

}	
	 
//��ɫ��ȫ��ʶ�𳬹�2��
	if(what_ball==4)
	{
			if(safe_red ==4)
		{
			time2++;
			if(time2==20) //!!!!!!!!>20?
			{
			flag2=1;
			}
		}
	}		
//��ɫ��ȫ��ʶ�𳬹�2��
if(what_ball==5)
	{
			if(safe_blue ==5)
		{
			time2++;
			if(time2==20) //!!!!!!!!>20?
			{
			flag2=1;
			}
		}
	}		 	
if((Speed_Left>=-28||Speed_Right<=+28)&&(flag==3||flag==11))
{
	  time3++;if(time3==20){flag3=1;}		
}	
}
	 

	if (htim->Instance == TIM7)
	{
		
		echo = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_1);
		time7++;echo_time++;
		if(time7==20){trig_flag=1;}
		if(trig_flag==0){HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_SET);}
		if(trig_flag==1){HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_RESET);}
		if(echo==1&&echo_flag==0){echo_time=0;echo_flag=1;}
		if(echo!=last_echo&&echo_flag==1){trig_flag=0;dis = time7;echo_flag=0;}
		last_echo = echo;
	}
}

double get_adc_val( ADC_HandleTypeDef *hadc)
{
	
	
	  HAL_ADC_Start(hadc);
		uint32_t adc=HAL_ADC_GetValue(hadc);
	  return (adc*3.3)/4096;
	
}




