#ifndef __MOTOR_H
#define __MOTOR_H

#include "main.h"
void Motor_Init(void);
void Motor1_SetSpeed(int16_t Speed);
void Motor2_SetSpeed(int16_t Speed);
void Motor3_SetSpeed(int16_t Speed);//left ǰ���ٶ�Ϊ�zzheng
void Motor4_SetSpeed(int16_t Speed);//rightǰ���ٶ�Ϊ��
#endif
