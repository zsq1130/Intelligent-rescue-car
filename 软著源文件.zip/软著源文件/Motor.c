#include "main.h"                  // Device header
#include "PWM.h"

void Motor1_SetSpeed(int16_t Speed)
{
	if(Speed==0)  //���1ͣת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, (GPIO_PinState)0);
		PWM_SetCompare1(Speed);
	}
	
	if(Speed<0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, (GPIO_PinState)1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, (GPIO_PinState)0);
		PWM_SetCompare1(-Speed);
	}
	if(Speed>0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, (GPIO_PinState)1);
		PWM_SetCompare1(Speed);
	}
}
void Motor2_SetSpeed(int16_t Speed)
{
	if(Speed==0)  //���1ͣת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, (GPIO_PinState)0);
		PWM_SetCompare2(Speed);
	}
	
	if(Speed<0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, (GPIO_PinState)1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, (GPIO_PinState)0);
		PWM_SetCompare2(-Speed);
	}
	if(Speed>0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, (GPIO_PinState)1);
		PWM_SetCompare2(Speed);
	}
}
void Motor3_SetSpeed(int16_t Speed)
{
	if(Speed==0)  //���1ͣת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, (GPIO_PinState)0);
		PWM_SetCompare3(Speed);//1.28
	}
	
	if(Speed<0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, (GPIO_PinState)1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, (GPIO_PinState)0);
		PWM_SetCompare3(-Speed);
	}
	if(Speed>0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, (GPIO_PinState)1);
		PWM_SetCompare3(Speed);
	}
}
void Motor4_SetSpeed(int16_t Speed)
{
	if(Speed==0)  //���1ͣת
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)0);
		PWM_SetCompare4(Speed);
	}
	
	if(Speed>0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, (GPIO_PinState)1);
		PWM_SetCompare4(Speed);
	}
	if(Speed<0)  //���1��ת
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)1);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, (GPIO_PinState)0);
		PWM_SetCompare4(-Speed);
	}
}
//PC4 PC5 PA3      PB0 PB1 PA2

