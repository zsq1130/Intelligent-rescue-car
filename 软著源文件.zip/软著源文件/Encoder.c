#include "encoder.h"                  // Device header




int16_t Encoder3_GetCNT(void)
{
	return (short)__HAL_TIM_GetCounter(&htim3);//Temp;
}
//����������
int16_t Encoder3_GetSpeed(void)
{
	int16_t Temp;
	Temp = Encoder3_GetCNT();
	__HAL_TIM_SetCounter(&htim3,0);
	return Temp;
}









int16_t Encoder4_GetCNT(void)
{
	return (short)__HAL_TIM_GetCounter(&htim4);//Temp;
}
//����������
int16_t Encoder4_GetSpeed(void)
{
	int16_t Temp;
	Temp = Encoder4_GetCNT();
	__HAL_TIM_SetCounter(&htim4,0);
	return Temp;
}
