#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h> 
#include <ctype.h> 
#include "usart.h"
#include "main.h" 
#include "Motor.h" 
extern pid_type_def X_pid;
extern pid_type_def Y_pid;
extern pid_type_def Left_speed_pid;
extern pid_type_def Right_speed_pid;
extern pid_type_def Left_speed_dalt_pid;
extern pid_type_def Right_speed_dalt_pid;
extern int Speed_Left;
extern int Speed_Right;
extern  fp32 x_ref_,y_ref_;
extern int what_ball;
extern UART_HandleTypeDef huart4;
extern UART_HandleTypeDef huart5;
extern int lose;
extern int count_;
extern int flag;
extern float Yaw_speed ;
#endif
