/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "timer.h"
#include "OLED.h"
#include "LED.h"
#include "PWM.h"
#include "Encoder.h"
#include "Motor.h"
#include "Walk.h"
#include "MPU6050.h"
#include "IMU.h"
#include "Serial.h"
#include "PID.h"
#include "string.h"
#include "stdio.h"
#include "SYS.h"
#include "PS2.h"
#include "pwm.h"
#include "PID_define.h"
/*********************����ı���****************/

int Speed_Left;
int Speed_Right;
float Roll=0 ,Pitch=0,Yaw=0 ;
float Yaw_speed ;
int red_or_blue=999;  //1blue 2red
int what_ball=0;
int led;
char temp[20];
double adc1,adc2;

uint8_t uart5RxData;//
uint8_t uart5RxBuff[11];//
uint8_t uart4RxData;//
uint8_t uart4RxBuff[25];//
uint8_t uart3RxData;//
uint8_t uart3RxBuff[11];//
uint8_t uart1RxData;//
uint8_t uart1RxBuff[11];//

/*********************EXTERN*******************/
extern int flag;
extern float a_x,a_y,a_z;
extern int round_;
extern int get_ball;
extern int count_;
extern int32_t sum_encode_left;
extern int32_t sum_encode_right;
extern uint16_t Echo_Measure(void);
extern float distance ;
#define low  1350
#define high 700


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM5_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM8_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  MX_TIM6_Init();
  MX_TIM7_Init();
  MX_USART3_UART_Init();
  MX_USART1_UART_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  /* USER CODE BEGIN 2 */
/**********************�������PWM���****************************/	
	HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_4);
/**********************�������PWM���****************************/				
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_4);
/**********************����������****************************/	
  HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_ALL);
	HAL_TIM_Encoder_Start(&htim4,TIM_CHANNEL_ALL);
/**********************������ʱ���ж�*************************/		 
  HAL_TIM_Base_Start_IT(&htim2);//100ms
  HAL_TIM_Base_Start_IT(&htim6);//20ms
//  HAL_TIM_Base_Start_IT(&htim7);//1ms
	MY_pid_Init();
/*******************�������ڽ����жϺ���***********************/
	HAL_UART_Receive_IT(&huart1,&uart1RxData,1);
	HAL_UART_Receive_IT(&huart3,&uart3RxData,1);
	HAL_UART_Receive_IT(&huart4,&uart4RxData,1);
	HAL_UART_Receive_IT(&huart5,&uart5RxData,1);
	
/*********************׼���׶��������*************************/
			 bihe();
//     quan_kai();
//	     quekou_close();//1740//1550  
       count_=2400;//2400
       PWM_DSetC2(count_);//����ͷ//1500 1225
//		 HAL_GPIO_TogglePin	(GPIOC,GPIO_PIN_1);//blue
//	     HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_0, GPIO_PIN_RESET);
			 HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_1, GPIO_PIN_SET);
//			 HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_13, GPIO_PIN_RESET);
//		 HAL_GPIO_TogglePin	(GPIOC,GPIO_PIN_13);//red flag = 33
       PWM_DSetC4(850);//1700max  2450min //2275  1080  1100     1300//700  1400  //1200 1350
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
//PC4 PC5 PA3      PB0 PB1 PA2
while(1)
{
//	zizhuan_pid();
//	Motor3_SetSpeed(-1000);//��
//	Motor4_SetSpeed(1000);//��
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
//						  Motor3_SetSpeed(-1800);//��
//		          Motor4_SetSpeed(-1800);//��

 while (flag==10000)
 {
				if(	HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_4)== GPIO_PIN_RESET)//��������ѡ��
			{
				led=2;
			}

			else
			{
				led=1;
			}
			if(led==1)   //����������
			{
					HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_1, GPIO_PIN_RESET);
					red_or_blue = 1;//��
				if(round_==1&&flag==10000)
					 {
						 what_ball=1;
					 }
			}
			else
			{
				HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_1, GPIO_PIN_SET);
			}
			if(led==2)   //�췽�����
			{
					HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_13, GPIO_PIN_RESET);
					red_or_blue = 2;//��
				   if(round_==1&&flag==10000)
					 {
						 what_ball=0;
					 }
			}
			else
			{
				HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_13, GPIO_PIN_SET);
			}
			if(	HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_5)== GPIO_PIN_SET)
			{
				count_=1740; PWM_DSetC4(700);
//				PWM_DSetC4(1750);//1500max  2450min 
//				quekou_close();
				
				bihe();
        PWM_DSetC2(count_);
				Motor3_SetSpeed(3500);//��
		    Motor4_SetSpeed(3500);//��
				if(sum_encode_left>1000&&sum_encode_right<-1000)
				{
					flag=0;get_ball=0;
				}
				HAL_GPIO_WritePin	(GPIOC,GPIO_PIN_0, GPIO_PIN_RESET);
			}
  }
}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
//void quan_kai(void)void quekou_close(void)void chuizhi_open(void)void bihe(void)

