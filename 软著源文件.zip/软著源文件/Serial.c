#include "Serial.h"                // Device header
#include "main.h" 
float a_x,a_y,a_z;
int red_,yellow_,black_,blue_,safe_blue,safe_red,go_red,go_blue,cross,number,x_safe,y_safe;
//float Roll_last,Pitch_last,Yaw_last,yaw,yaw_flag=0;


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	static uint8_t rxBuff1[128];
  static uint8_t rxCount1;
//	static uint8_t rxBuff2[128];
//  static uint8_t rxCount2;
	static uint8_t rxBuff3[128];
  static uint8_t rxCount3;
/*******************����4��������ͷ����******************/			
  if(huart==&huart4)
  {
    rxBuff1[rxCount1++]=uart4RxData;
		if((rxBuff1[rxCount1-25]=='@')&&rxBuff1[rxCount1-1]=='\n')
		{
     memcpy(uart4RxBuff,&rxBuff1[rxCount1-25],24);
     memset(rxBuff1,0,128);
			rxCount1=0;
						
			uart4RxBuff[1] = uart4RxBuff[1]  - 48;
			uart4RxBuff[2] = uart4RxBuff[2]  - 48;
			uart4RxBuff[3] = uart4RxBuff[3]  - 48;
			uart4RxBuff[4] = uart4RxBuff[4]  - 48;
			uart4RxBuff[5] = uart4RxBuff[5]  - 48;
			uart4RxBuff[6] = uart4RxBuff[6]  - 48;
			uart4RxBuff[7] = uart4RxBuff[7]  - 48;
			uart4RxBuff[8] = uart4RxBuff[8]  - 48;
			uart4RxBuff[9] = uart4RxBuff[9]  - 48;
			uart4RxBuff[10]= uart4RxBuff[10] - 48;
			uart4RxBuff[11]= uart4RxBuff[11] - 48;
			uart4RxBuff[12]= uart4RxBuff[12] - 48;	
      uart4RxBuff[13]= uart4RxBuff[13] - 48;			
		  uart4RxBuff[14]= uart4RxBuff[14] - 48;
			uart4RxBuff[15]= uart4RxBuff[15] - 48;
			uart4RxBuff[16]= uart4RxBuff[16] - 48;
			
		  uart4RxBuff[17]= uart4RxBuff[17] - 48;
			uart4RxBuff[18]= uart4RxBuff[18] - 48;	
      uart4RxBuff[19]= uart4RxBuff[19] - 48;			
		  uart4RxBuff[20]= uart4RxBuff[20] - 48;
			uart4RxBuff[21]= uart4RxBuff[21] - 48;
			uart4RxBuff[22]= uart4RxBuff[22] - 48;


			if	(((uart4RxBuff[7]*100 + uart4RxBuff[8]*10 + uart4RxBuff[9])!=0)&&((uart4RxBuff[10]*100 + uart4RxBuff[11]*10 + uart4RxBuff[12])!=240))
				{
						x_ref_ =	((int)uart4RxBuff[7])*100 + ((int)uart4RxBuff[8])*10 + ((int)uart4RxBuff[9]);
						y_ref_ =	((int)uart4RxBuff[10])*100 + ((int)uart4RxBuff[11])*10 + ((int)uart4RxBuff[12]);			
				}
			if((x_ref_!=0)&&(y_ref_!=0))
			{
				x_ref=x_ref_;
				y_ref=y_ref_;
			}//0 1 2 3 red_ blue_ yellow_ black_
			red_     =   uart4RxBuff[1];//0
		  blue_ 	 =   uart4RxBuff[2];
			black_   =   uart4RxBuff[3];
			yellow_  =   uart4RxBuff[4];
			safe_red =   uart4RxBuff[5];
			safe_blue=   uart4RxBuff[6];
      go_red   =   uart4RxBuff[13];
      go_blue  =   uart4RxBuff[14];//7
			cross    =	 uart4RxBuff[15];//8
			number   =	 uart4RxBuff[16];//9
      x_safe =	((int)uart4RxBuff[17])*100 + ((int)uart4RxBuff[18])*10 + ((int)uart4RxBuff[19]);
      y_safe =	((int)uart4RxBuff[20])*100 + ((int)uart4RxBuff[21])*10 + ((int)uart4RxBuff[22]);	
		}
			if(rxCount1==128) {rxCount1=0;}
			HAL_UART_Receive_IT(&huart4,&uart4RxData,1);
	}
/*******************���������Ǽ��ٶ�����******************/			
//	 if(huart==&huart3)
//  { 
//    rxBuff3[rxCount3++]=uart3RxData;
//    if(((rxBuff3[rxCount3-11]==0x55)&&(rxBuff3[rxCount3-10]==0x53)))
//		{
//     memcpy(uart3RxBuff,&rxBuff3[rxCount3-11],10);
//     memset(rxBuff3,0,128);
//		 rxCount3=0;
//		 a_x = (int16_t)((uart3RxBuff[3] << 8) | uart3RxBuff[2]);
//		 a_y = (int16_t)((uart3RxBuff[5] << 8) | uart3RxBuff[4]);
//     a_z = (int16_t)((uart3RxBuff[7] << 8) | uart3RxBuff[6]); 
//			
//		 a_x=a_x/32768.0f*1000.0f;
//		 a_y=a_y/32768.0f*1000.0f;
//		 a_z=a_z/32768.0f*1000.0f;
//		}
//		if(rxCount3==128) {rxCount3=0;}
//		HAL_UART_Receive_IT(&huart3,&uart3RxData,1);
//	}
/*******************����3���������ǽǶȺͽ��ٶ�����******************/		
if(huart==&huart3)
  { 

		
    rxBuff3[rxCount3++]=uart3RxData;
    if((rxBuff3[rxCount3-11]==0x55&&rxBuff3[rxCount3-10]==0x53))
		{
     memcpy(uart3RxBuff,&rxBuff3[rxCount3-11],10);
     memset(rxBuff3,0,128);
		 rxCount3=0;
//	 Roll=(int16_t)((uart3RxBuff[3] << 8) | uart3RxBuff[2]);
//	 Pitch = (int16_t)((uart3RxBuff[5] << 8) |uart3RxBuff[4]);
//	 Roll=Roll/32768.0f*180.0f;
//	 Pitch=Pitch/32768.0f*180.0f;
     Yaw = (int16_t)((uart3RxBuff[7] << 8) | uart3RxBuff[6]); 
		 Yaw=Yaw/32768.0f*180.0f;
		}
		
		
		
		
		 if((rxBuff3[rxCount3-11]==0x55&&rxBuff3[rxCount3-10]==0x52))
		{
     memcpy(uart3RxBuff,&rxBuff3[rxCount3-11],10);
     memset(rxBuff3,0,128);
		 rxCount3=0;
//		 Roll=(int16_t)((uart3RxBuff[3] << 8) | uart3RxBuff[2]);
//		 Pitch = (int16_t)((uart3RxBuff[5] << 8) |uart3RxBuff[4]);
     Yaw_speed = (int16_t)((uart3RxBuff[7] << 8) | uart3RxBuff[6]); 
//		 Roll=Roll/32768.0f*180.0f;
//		 Pitch=Pitch/32768.0f*180.0f;
//		 Yaw_speed=Yaw_speed;
		}

		  if(rxCount3==128) {rxCount3=0;}
		  HAL_UART_Receive_IT(&huart3,&uart3RxData,1);
//		sprintf(temp,"%f,%f,%f,%f\n", a_x,a_y,a_z,Roll);
//		HAL_UART_Transmit(&huart5,(uint8_t *)temp,strlen(temp),50);	 
	}
}




	 void error_(void)
{	
//		 	if(x_ref!=0&&y_ref!=0&&get_ball==0&&(flag==0||flag==1)&&FLAG==0)
//				{
//					
//					if(time_task1_flag==1)
//					{
//						sss=44;
//						quekou_close();
//							Motor3_SetSpeed(-5000);//��
//							Motor4_SetSpeed(5000);//��
//							if(sum_encode_left<-700||sum_encode_right<-700)
//							{
//								
//								time_task1=0;
//								time_task1_flag=0;
//									sum_encode_left=0;
//						      sum_encode_right=0;
//								flag=0; FLAG=0;get_ball=0;
//							 close_boll(); 	
//                 sss=55;								
//							}
//						
//					}
//					
//					
//					else 
//					{
//				  close_boll();sss=66;
//						sum_encode_left=0;
//						sum_encode_right=0;
//					}
//				}

//				if(get_ball==1&&count_>=1200&&(flag==2||flag==3||flag==4)&&FLAG==0)
//				{
//				 goto_safe();
//					
//					sss=2;
//				}
//				
//				if(FLAG==1)
//				{
//					find_ball();
//				}
//				if((what_ball==6||what_ball==7)&&FLAG==2)
//				{
//					go_go();
//				}
//				if(flag==6)
//				{
//					check();
//				}
//	zizhuan_pid();
}


